// js/bancos/bandec.js - COMPLETO con todas las operaciones
const datosBANDEC = [
    // ===== SESIÓN =====
    {nombre:"🔑 Autenticarse",codigo:"AUTENTICAR",categoria:"sesion",descripcion:"Iniciar sesión (*444*40*02#)",accion:"auth"},
    {nombre:"🚪 Desconectar",codigo:"*444*70#",categoria:"sesion",descripcion:"Cerrar sesión"},
    {nombre:"🔄 Cambio de Tarjeta",codigo:"*444*60#",categoria:"sesion",descripcion:"Cambiar tarjeta a operar"},
    
    // ===== CONSULTAS =====
    {nombre:"💰 Consultar Saldo",codigo:"*444*46#",categoria:"consultas",descripcion:"Consultar saldo de tarjetas"},
    {nombre:"📱 Consultar Servicio",codigo:"*444*47#",categoria:"consultas",descripcion:"Consultar estado del servicio"},
    {nombre:"📋 Últimas Operaciones",codigo:"*444*48#",categoria:"consultas",descripcion:"Consultar últimas operaciones"},
    {nombre:"📋 Consulta ONAT",codigo:"ONAT",categoria:"consultas",descripcion:"Consulta de impuestos con RC05",accion:"onat"},
    {nombre:"🔍 Consultar Todas las Cuentas",codigo:"*444*58#",categoria:"consultas",descripcion:"Consultar todas tus cuentas"},
    {nombre:"📏 Consultar Límites",codigo:"*444*62#",categoria:"consultas",descripcion:"Consultar límites de tarjeta"},
    {nombre:"📋 Últimos Pagos",codigo:"*444*63#",categoria:"consultas",descripcion:"Consultar últimos pagos de servicios"},
    {nombre:"🔍 Consulta Giro Postal",codigo:"CONSULTAGIRO",categoria:"consultas",descripcion:"Consultar estado de un giro",accion:"consultaGiro"},
    {nombre:"💳 Información de Tarjeta",codigo:"*444*78#",categoria:"consultas",descripcion:"Información detallada de tarjeta"},
    {nombre:"💱 Tipo de Cambio",codigo:"*444*85#",categoria:"consultas",descripcion:"Consultar tipo de cambio"},
    
    // ===== SERVICIOS CONTRATADOS =====
    {nombre:"📄 Adicionar Facturas",codigo:"*444*52#",categoria:"servicios",descripcion:"Adicionar, consultar y revisar facturas"},
    
    // ===== OPERACIONES =====
    {nombre:"💡 Pagar Electricidad",codigo:"*444*41#",categoria:"operaciones",descripcion:"Pagar factura eléctrica"},
    {nombre:"📞 Pagar Teléfono",codigo:"*444*42#",categoria:"operaciones",descripcion:"Pagar servicios telefónicos"},
    {nombre:"🏛️ Pagar ONAT",codigo:"*444*43#",categoria:"operaciones",descripcion:"Pagar impuestos ONAT"},
    {nombre:"💸 Transferir",codigo:"*444*45#",categoria:"operaciones",descripcion:"Transferir dinero a otra cuenta"},
    {nombre:"🚰 Pagar Agua (Habana)",codigo:"*444*51#",categoria:"operaciones",descripcion:"Pagar servicio de agua en La Habana"},
    {nombre:"📱 Recarga Móvil",codigo:"*444*54#",categoria:"operaciones",descripcion:"Recargar saldo de teléfono móvil"},
    {nombre:"🏦 Amortizar Crédito",codigo:"*444*55#",categoria:"operaciones",descripcion:"Amortizar créditos personales"},
    {nombre:"🌐 Recarga Nauta",codigo:"*444*59#",categoria:"operaciones",descripcion:"Recargar cuenta permanente Nauta"},
    {nombre:"📮 Giro Postal",codigo:"GIRO",categoria:"operaciones",descripcion:"Enviar giro postal",accion:"giroPanel"},
    {nombre:"🔥 Pagar Gas",codigo:"*444*67#",categoria:"operaciones",descripcion:"Pagar servicio de gas"},
    {nombre:"💳 Recargar Tarjeta Propia",codigo:"*444*77#",categoria:"operaciones",descripcion:"Recargar tu propia tarjeta"},
    {nombre:"🏠 Pagar Nauta Hogar",codigo:"*444*84#",categoria:"operaciones",descripcion:"Pagar cuota de Nauta Hogar"},
    {nombre:"📊 Pagar Deuda Hogar",codigo:"*444*86#",categoria:"operaciones",descripcion:"Pagar deuda de Nauta Hogar"},
    {nombre:"🔄 Recargar Joven Club",codigo:"*444*93#",categoria:"operaciones",descripcion:"Recargar cuentas Joven Club"},
    
    // ===== CONFIGURACIÓN =====
    {nombre:"📝 Registrarse",codigo:"REGISTRAR",categoria:"configuracion",descripcion:"Registrar tarjeta en el sistema",accion:"registrar"},
    {nombre:"🔑 Cambiar PIN",codigo:"*444*57#",categoria:"configuracion",descripcion:"Cambiar PIN de tarjeta Multifunción"},
    {nombre:"📊 Cambiar Límites",codigo:"*444*61#",categoria:"configuracion",descripcion:"Cambiar límites de tarjeta"},
    {nombre:"🗑️ Eliminar Registro",codigo:"*444*68*02#",categoria:"configuracion",descripcion:"Eliminar registro de tarjeta"},
    {nombre:"🔑 Cambiar Clave",codigo:"*444*69#",categoria:"configuracion",descripcion:"Cambiar clave de seguridad"},
    {nombre:"🔄 Reemplazar Tarjeta",codigo:"*444*74#",categoria:"configuracion",descripcion:"Reemplazar tarjeta"},
    {nombre:"💳 Imprimir Tarjeta USD",codigo:"*444*76#",categoria:"configuracion",descripcion:"Imprimir tarjeta en USD (MLC)"},
    {nombre:"🔐 Generar PIN no Impreso",codigo:"*444*79#",categoria:"configuracion",descripcion:"Generar PIN no impreso"}
];

let bandecCategoriaActual = 'todas';
let bandecSearchTerm = '';

function renderBANDEC() {
    const list = document.getElementById('bandecList');
    if (!list) return;
    let filtradas = datosBANDEC;
    if (bandecCategoriaActual !== 'todas') {
        filtradas = filtradas.filter(op => op.categoria === bandecCategoriaActual);
    }
    if (bandecSearchTerm) {
        filtradas = filtradas.filter(op => op.nombre.toLowerCase().includes(bandecSearchTerm) || op.descripcion.toLowerCase().includes(bandecSearchTerm));
    }
    if (filtradas.length === 0) {
        list.innerHTML = `<div style="text-align:center;padding:30px 0;color:#8aa89a;">🔍 No se encontraron operaciones</div>`;
        return;
    }
    let html = '';
    filtradas.forEach(op => {
        const disabled = op.requiereSesion && !app.sesionActiva;
        const lockHtml = op.requiereSesion ? `<span class="lock-icon">🔒</span>` : '';
        let onclick = '';
        if (!disabled) {
            if (op.accion === 'auth') {
                onclick = `app.autenticar('bandec')`;
            } else if (op.accion === 'giroPanel') {
                onclick = `app.abrirPanelGiroPostal()`;
            } else if (op.accion === 'onat') {
                onclick = `app.abrirPanelONAT()`;
            } else if (op.accion === 'consultaGiro') {
                onclick = `app.abrirPanelConsultaGiro('bandec')`;
            } else if (op.accion === 'registrar') {
                onclick = `app.abrirPanelRegistro('bandec')`;
            } else {
                onclick = `app.marcarUssd('${op.codigo}')`;
            }
        }
        html += `<div class="operation-card ${disabled?'disabled':''}" onclick="${disabled?'':onclick}">
            <div class="operation-info">
                <div class="operation-name">${op.nombre} ${lockHtml}</div>
                <div class="operation-desc">${op.descripcion}</div>
            </div>
            <span class="operation-phone ${disabled?'disabled':''}">📞</span>
        </div>`;
    });
    list.innerHTML = html;
}

function filtrarBANDECCategoria(cat, btn) {
    bandecCategoriaActual = cat;
    const container = document.querySelector('#bandecContainer .categories');
    if (container) {
        container.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
    }
    renderBANDEC();
}

function filtrarBANDEC() {
    const searchBox = document.getElementById('searchBoxBANDEC');
    if (searchBox) {
        bandecSearchTerm = searchBox.value.toLowerCase().trim();
        renderBANDEC();
    }
}

function initBANDEC() {
    renderBANDEC();
}

window.initBANDEC = initBANDEC;
window.filtrarBANDEC = filtrarBANDEC;
window.filtrarBANDECCategoria = filtrarBANDECCategoria;