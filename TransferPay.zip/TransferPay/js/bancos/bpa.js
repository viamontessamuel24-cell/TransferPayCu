// js/bancos/bpa.js - COMPLETO con todas las operaciones
const datosBPA = [
    // ===== SESIÓN =====
    {nombre:"🔑 Autenticarse",codigo:"AUTENTICAR",categoria:"sesion",descripcion:"Iniciar sesión (*444*40*01#)",accion:"auth"},
    {nombre:"🚪 Desconectar",codigo:"*444*70#",categoria:"sesion",descripcion:"Cerrar sesión"},
    
    // ===== CONSULTAS =====
    {nombre:"💰 Consultar Saldo",codigo:"*444*46#",categoria:"consultas",descripcion:"Ver saldo disponible"},
    {nombre:"🔍 Consultar Integrada",codigo:"*444*58#",categoria:"consultas",descripcion:"Consulta múltiple integrada"},
    {nombre:"📱 Consultar Servicio",codigo:"*444*47#",categoria:"consultas",descripcion:"Estado del servicio"},
    {nombre:"📋 Últimas Operaciones",codigo:"*444*48#",categoria:"consultas",descripcion:"Historial de movimientos"},
    {nombre:"📏 Consulta de Límites",codigo:"*444*62#",categoria:"consultas",descripcion:"Ver límites de transferencia"},
    {nombre:"🔍 Consulta Giro Postal",codigo:"CONSULTAGIRO",categoria:"consultas",descripcion:"Consultar estado de un giro",accion:"consultaGiro"},
    {nombre:"💳 Consultar Créditos",codigo:"*444*72#",categoria:"consultas",descripcion:"Ver créditos disponibles"},
    {nombre:"💱 Tipo de Cambio",codigo:"*444*85#",categoria:"consultas",descripcion:"Consultar tipo de cambio"},
    
    // ===== OPERACIONES =====
    {nombre:"💸 Transferencia",codigo:"*444*45#",categoria:"operaciones",descripcion:"Enviar dinero"},
    {nombre:"💡 Pagar Electricidad",codigo:"*444*41#",categoria:"operaciones",descripcion:"Pago de factura eléctrica"},
    {nombre:"📞 Pagar Teléfono",codigo:"*444*42#",categoria:"operaciones",descripcion:"Pago de servicios telefónicos"},
    {nombre:"🏛️ Pagar ONAT",codigo:"*444*43#",categoria:"operaciones",descripcion:"Pago de impuestos ONAT"},
    {nombre:"🚰 Pagar Aguas Habana",codigo:"*444*51#",categoria:"operaciones",descripcion:"Pago de servicio de agua (La Habana)"},
    {nombre:"🔥 Pagar Gas",codigo:"*444*67#",categoria:"operaciones",descripcion:"Pago de servicio de gas"},
    {nombre:"📱 Recarga Móvil",codigo:"*444*54#",categoria:"operaciones",descripcion:"Recargar saldo de teléfono móvil"},
    {nombre:"📮 Giro Postal",codigo:"GIRO",categoria:"operaciones",descripcion:"Enviar giro postal",accion:"giroPanel"},
    {nombre:"🌐 Recarga Nauta",codigo:"*444*59#",categoria:"operaciones",descripcion:"Recargar cuenta Nauta"},
    {nombre:"🏠 Pago Cuota Nauta Hogar",codigo:"*444*84#",categoria:"operaciones",descripcion:"Pagar cuota de Nauta Hogar"},
    {nombre:"📊 Pago Deuda Nauta Hogar",codigo:"*444*86#",categoria:"operaciones",descripcion:"Pagar deuda de Nauta Hogar"},
    {nombre:"🏦 Amortizar Créditos",codigo:"*444*55#",categoria:"operaciones",descripcion:"Amortizar créditos personales"},
    {nombre:"💳 Recarga Propia",codigo:"*444*77#",categoria:"operaciones",descripcion:"Recargar tu propia tarjeta"},
    {nombre:"📅 Crear Depósito a Plazo Fijo",codigo:"*444*81#",categoria:"operaciones",descripcion:"Crear depósito a plazo fijo"},
    {nombre:"🔒 Cerrar Depósito a Plazo Fijo",codigo:"*444*82#",categoria:"operaciones",descripcion:"Cerrar depósito a plazo fijo"},
    {nombre:"🔄 Recarga Cuentas Joven Club",codigo:"*444*93#",categoria:"operaciones",descripcion:"Recargar cuentas Joven Club"},
    
    // ===== CONFIGURACIÓN =====
    {nombre:"📝 Registrarse",codigo:"REGISTRAR",categoria:"configuracion",descripcion:"Registrar tarjeta en el sistema",accion:"registrar"},
    {nombre:"🔑 Cambiar Clave",codigo:"*444*69#",categoria:"configuracion",descripcion:"Cambiar clave de Banca Móvil"},
    {nombre:"🗑️ Eliminar Registro",codigo:"*444*68*01#",categoria:"configuracion",descripcion:"Eliminar registro de tarjeta"},
    {nombre:"📊 Cambio de Límites",codigo:"*444*61#",categoria:"configuracion",descripcion:"Modificar límites de tarjeta"},
    {nombre:"💳 Asociar Cuentas",codigo:"*444*60#",categoria:"configuracion",descripcion:"Asociar cuentas a la tarjeta"},
    {nombre:"🔐 Generar PIN no Impreso",codigo:"*444*79#",categoria:"configuracion",descripcion:"Generar PIN no impreso"},
    {nombre:"🖨️ Reimprimir Tarjeta",codigo:"*444*74#",categoria:"configuracion",descripcion:"Reimprimir tarjeta"},
    {nombre:"⚠️ Pérdida de PIN Tarjeta",codigo:"*444*83#",categoria:"configuracion",descripcion:"Reportar pérdida de PIN"}
];

let bpaCategoriaActual = 'todas';
let bpaSearchTerm = '';

function renderBPA() {
    const list = document.getElementById('bpaList');
    if (!list) return;
    let filtradas = datosBPA;
    if (bpaCategoriaActual !== 'todas') {
        filtradas = filtradas.filter(op => op.categoria === bpaCategoriaActual);
    }
    if (bpaSearchTerm) {
        filtradas = filtradas.filter(op => op.nombre.toLowerCase().includes(bpaSearchTerm) || op.descripcion.toLowerCase().includes(bpaSearchTerm));
    }
    if (filtradas.length === 0) {
        list.innerHTML = `<div style="text-align:center;padding:30px 0;color:#8aa89a;">🔍 No se encontraron operaciones</div>`;
        return;
    }
    let html = '';
    filtradas.forEach(op => {
        const disabled = op.requiereSesion && !app.sesionActiva;
        const lockHtml = op.requiereSesion ? `<span class="lock-icon">🔒</span>` : '';
        let onclick = '';
        if (!disabled) {
            if (op.accion === 'auth') {
                onclick = `app.autenticar('bpa')`;
            } else if (op.accion === 'giroPanel') {
                onclick = `app.abrirPanelGiroPostal()`;
            } else if (op.accion === 'consultaGiro') {
                onclick = `app.abrirPanelConsultaGiro('bpa')`;
            } else if (op.accion === 'registrar') {
                onclick = `app.abrirPanelRegistro('bpa')`;
            } else {
                onclick = `app.marcarUssd('${op.codigo}')`;
            }
        }
        html += `<div class="operation-card ${disabled?'disabled':''}" onclick="${disabled?'':onclick}">
            <div class="operation-info">
                <div class="operation-name">${op.nombre} ${lockHtml}</div>
                <div class="operation-desc">${op.descripcion}</div>
            </div>
            <span class="operation-phone ${disabled?'disabled':''}">📞</span>
        </div>`;
    });
    list.innerHTML = html;
}

function filtrarBPACategoria(cat, btn) {
    bpaCategoriaActual = cat;
    const container = document.querySelector('#bpaContainer .categories');
    if (container) {
        container.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
    }
    renderBPA();
}

function filtrarBPA() {
    const searchBox = document.getElementById('searchBoxBPA');
    if (searchBox) {
        bpaSearchTerm = searchBox.value.toLowerCase().trim();
        renderBPA();
    }
}

function initBPA() {
    renderBPA();
}

window.initBPA = initBPA;
window.filtrarBPA = filtrarBPA;
window.filtrarBPACategoria = filtrarBPACategoria;