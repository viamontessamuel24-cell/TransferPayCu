// js/bancos/banmet.js
const datosBANMET = [
    {nombre:"🔑 Autenticarse",codigo:"AUTENTICAR",categoria:"sesion",descripcion:"Iniciar sesión (*444*40*03#)",accion:"auth"},
    {nombre:"🚪 Desconectarse",codigo:"*444*70#",categoria:"sesion",descripcion:"Cerrar sesión"},
    {nombre:"💰 Consultar Saldo",codigo:"*444*46#",categoria:"consultas",descripcion:"Ver saldo disponible"},
    {nombre:"📱 Consultar Servicio",codigo:"*444*47#",categoria:"consultas",descripcion:"Estado del servicio"},
    {nombre:"🏛️ Consulta ONAT",codigo:"*444*56#",categoria:"consultas",descripcion:"Consulta de impuestos"},
    {nombre:"📊 Consulta ONAT Anual",codigo:"*444*57#",categoria:"consultas",descripcion:"Consulta anual de impuestos"},
    {nombre:"📋 Últimas Operaciones",codigo:"*444*48#",categoria:"consultas",descripcion:"Historial de movimientos"},
    {nombre:"📏 Consulta de Límites",codigo:"*444*62#",categoria:"consultas",descripcion:"Ver límites de transferencia"},
    {nombre:"🔍 Consultar Todas las Cuentas",codigo:"*444*58#",categoria:"consultas",descripcion:"Ver todas tus cuentas"},
    {nombre:"📮 Consulta Giro Postal",codigo:"*444*65#",categoria:"consultas",descripcion:"Estado de giros"},
    {nombre:"📍 Localizar Transferencia",codigo:"*444*73#",categoria:"consultas",descripcion:"Localizar una transferencia"},
    {nombre:"💱 Tipo de Cambio",codigo:"*444*85#",categoria:"consultas",descripcion:"Consultar tipo de cambio"},
    {nombre:"💸 Transferencia",codigo:"*444*45#",categoria:"operaciones",descripcion:"Enviar dinero"},
    {nombre:"💡 Pagar Electricidad",codigo:"*444*41#",categoria:"operaciones",descripcion:"Pago de factura eléctrica"},
    {nombre:"📞 Teléfono",codigo:"*444*42#",categoria:"operaciones",descripcion:"Pago de servicios telefónicos"},
    {nombre:"🏛️ Pago ONAT",codigo:"*444*43#",categoria:"operaciones",descripcion:"Pago de impuestos"},
    {nombre:"🔥 Gas",codigo:"*444*67#",categoria:"operaciones",descripcion:"Pago de gas"},
    {nombre:"📱 Recarga Saldo Móvil",codigo:"*444*54#",categoria:"operaciones",descripcion:"Recargar saldo de celular"},
    {nombre:"📮 Giro Postal",codigo:"GIRO",categoria:"operaciones",descripcion:"Enviar giro postal",accion:"giroPanel"},
    {nombre:"🌐 Recarga Nauta",codigo:"*444*59#",categoria:"operaciones",descripcion:"Recargar Nauta"},
    {nombre:"🏠 Pagar Cuota Nauta Hogar",codigo:"*444*84#",categoria:"operaciones",descripcion:"Pagar cuota de Nauta Hogar"},
    {nombre:"📊 Pago Deuda Nauta Hogar",codigo:"*444*86#",categoria:"operaciones",descripcion:"Pagar deuda de Nauta Hogar"},
    {nombre:"💳 Recarga Tarjeta Propia",codigo:"*444*77#",categoria:"operaciones",descripcion:"Recargar tu propia tarjeta"},
    {nombre:"🔄 Recarga Cuentas Joven Club",codigo:"*444*93#",categoria:"operaciones",descripcion:"Recargar cuentas Joven Club"},
    {nombre:"📝 Registrarse",codigo:"REGISTRAR",categoria:"configuracion",descripcion:"Registrar tarjeta en el sistema",accion:"registrar"},
    {nombre:"📊 Cambio de Límites",codigo:"*444*61#",categoria:"configuracion",descripcion:"Modificar límites"},
    {nombre:"🗑️ Eliminar Registro",codigo:"*444*68*03#",categoria:"configuracion",descripcion:"Eliminar tarjeta"},
    {nombre:"🔢 Cambio de PIN",codigo:"*444*69#",categoria:"configuracion",descripcion:"Cambiar PIN de seguridad"},
    {nombre:"💳 Asociar Cuenta",codigo:"*444*60#",categoria:"configuracion",descripcion:"Asociar nueva cuenta"},
    {nombre:"🔄 Actualizar Cuenta",codigo:"*444*53#",categoria:"configuracion",descripcion:"Actualizar datos de cuenta"},
    {nombre:"🖨️ Reimpresión de Tarjetas",codigo:"*444*74#",categoria:"configuracion",descripcion:"Reimprimir tarjeta"},
    {nombre:"🔐 PIN Digital",codigo:"*444*79#",categoria:"configuracion",descripcion:"Generar PIN digital"},
    {nombre:"💵 Apertura Cuenta MLC",codigo:"*444*76#",categoria:"configuracion",descripcion:"Abrir cuenta en MLC"}
];

let banmetCategoriaActual = 'todas';
let banmetSearchTerm = '';

function renderBANMET() {
    const list = document.getElementById('banmetList');
    if (!list) return;
    let filtradas = datosBANMET;
    if (banmetCategoriaActual !== 'todas') {
        filtradas = filtradas.filter(op => op.categoria === banmetCategoriaActual);
    }
    if (banmetSearchTerm) {
        filtradas = filtradas.filter(op => op.nombre.toLowerCase().includes(banmetSearchTerm) || op.descripcion.toLowerCase().includes(banmetSearchTerm));
    }
    if (filtradas.length === 0) {
        list.innerHTML = `<div style="text-align:center;padding:30px 0;color:#8aa89a;">🔍 No se encontraron operaciones</div>`;
        return;
    }
    let html = '';
    filtradas.forEach(op => {
        const disabled = op.requiereSesion && !app.sesionActiva;
        const lockHtml = op.requiereSesion ? `<span class="lock-icon">🔒</span>` : '';
        let onclick = '';
        if (!disabled) {
            if (op.accion === 'auth') {
                onclick = `app.autenticar('banmet')`;
            } else if (op.accion === 'giroPanel') {
                onclick = `app.abrirPanelGiroPostal()`;
            } else if (op.accion === 'registrar') {
                onclick = `app.abrirPanelRegistro('banmet')`;
            } else {
                onclick = `app.marcarUssd('${op.codigo}')`;
            }
        }
        html += `<div class="operation-card ${disabled?'disabled':''}" onclick="${disabled?'':onclick}">
            <div class="operation-info">
                <div class="operation-name">${op.nombre} ${lockHtml}</div>
                <div class="operation-desc">${op.descripcion}</div>
            </div>
            <span class="operation-phone ${disabled?'disabled':''}">📞</span>
        </div>`;
    });
    list.innerHTML = html;
}

function filtrarBANMETCategoria(cat, btn) {
    banmetCategoriaActual = cat;
    const container = document.querySelector('#banmetContainer .categories');
    if (container) {
        container.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
    }
    renderBANMET();
}

function filtrarBANMET() {
    const searchBox = document.getElementById('searchBoxBANMET');
    if (searchBox) {
        banmetSearchTerm = searchBox.value.toLowerCase().trim();
        renderBANMET();
    }
}

function initBANMET() {
    renderBANMET();
}

window.initBANMET = initBANMET;
window.filtrarBANMET = filtrarBANMET;
window.filtrarBANMETCategoria = filtrarBANMETCategoria;